﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Exercises.DecisionTree
{
    public class Range
    {
        public readonly Question _question;
        private readonly int _mininmumValue;
        private readonly int _maximumValue;
        
        public Range(Question question, int mininmumValue, int maximumValue)
        {
            _question = question;
            _mininmumValue = mininmumValue;
            _maximumValue = maximumValue;
        }

        public static Question NextQuestion( List<Range> ranges, int? reply) =>
            ranges.First(range =>IsInRange(range,reply))._question.NextQuestion();

        public static bool IsInRange(Range range, int? reply) =>
            (range._mininmumValue <= reply && range._maximumValue >= reply);
    }
}