﻿namespace Exercises.DecisionTree;

public class NumericQuestion:Question
{
    public string _question;
    private readonly Question _answer;
    private int? _reply=null;
    public NumericQuestion(string question, Question answer)
    {
        _question = question;
        _answer = answer;
    }
    public string QuestionReturn()
    {
        return _question;
    }
    public void Be(string reply)
    {
        if (int.TryParse(reply, out int parsedValue) && parsedValue >= 0)
            _reply = parsedValue;

    }
    public Question NextQuestion()
    {
        if (_reply == null) return this;
        return _answer.NextQuestion();
    }

}